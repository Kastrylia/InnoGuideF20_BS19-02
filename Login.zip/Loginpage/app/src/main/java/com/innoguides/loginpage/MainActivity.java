package com.innoguides.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
private EditText email,password;
private Button authorize,reg;
DBhelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email=findViewById(R.id.aEmail);
        password=findViewById(R.id.aPassword);
        authorize=findViewById(R.id.toAut);
        reg=findViewById(R.id.reg);
        db=new DBhelper(this);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,registration.class);
                startActivity(intent);
            }

        });

        authorize.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String Password=(String)password.getText().toString();
                String Email=(String)email.getText().toString();
                Boolean checker=db.authorization(Email,Password);
                if (checker) setContentView(R.layout.activity_main2);
                else setContentView(R.layout.activity_main2);

            }

        });

    }
}